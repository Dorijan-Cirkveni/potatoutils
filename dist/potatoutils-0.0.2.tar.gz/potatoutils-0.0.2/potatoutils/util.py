def signum(a, b):
    return int(a < b) - int(a > b)
