from potatoutils import util


def test_signum():
    assert util.signum(0, 0) == 0
