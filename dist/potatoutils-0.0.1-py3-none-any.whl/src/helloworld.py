def fucking_work_goddamnit():
    print("Fucking finally")
    return

if __name__ == "__main__":
    print("Hello World")
